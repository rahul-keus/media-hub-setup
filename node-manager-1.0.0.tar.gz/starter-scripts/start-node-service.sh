#!/bin/bash

cd /keus-iot-platform/node-manager/server/
node ./inter-service-index.js
