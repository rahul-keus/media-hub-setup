#!/bin/sh

cd /keus-iot-platform/node-manager/ui/
node server.js
