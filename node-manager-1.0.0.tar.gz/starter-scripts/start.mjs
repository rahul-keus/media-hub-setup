import fs from 'fs';
import { $, cd, nothrow  } from '/usr/lib/node_modules/zx/build/index.js';

const AsyncDelay = function(delay) {
	return new Promise((resolve) => {
		setTimeout(function() {
			resolve({});
		}, delay);
	});
};

(async () => {
  await cd(`/data/keus-iot-platform/`);
  await nothrow($`pkill dnsmasq`);
  await $`chmod +x /data/keus-iot-platform/starter-scripts/start-node-plugin.sh`;

  if (!fs.existsSync('/data/keus-iot-platform/storage/node-leaf/leaf.conf')) {
    await $`mkdir -p /data/keus-iot-platform/storage/node-leaf/`;
    await $`cp /data/keus-iot-platform/nats-conf/leaf.conf /data/keus-iot-platform/storage/node-leaf/leaf.conf`;
  }

  try {
    await nothrow($`podman rm -f $(podman ps -a -q)`);
    await AsyncDelay(10000);
  } catch (err) {
	  console.log('Error removing stale old containers', err);
  }

  await $`podman run --privileged --name kiotp_nats_main_server -d \
    --restart always \
    --log-driver k8s-file \
    --log-opt path=/data/keus-iot-platform/logs/kiotp_nats_main_server.json \
    --log-opt max-size=20mb \
    --log-opt max-file=10 \
    -v /data/keus-iot-platform:/keus-iot-platform \
    -e NODE_ENV=production \
    --network kiotp-network \
    -p "9765:9765" -p "9766:9766" -p "9767:9767" -p "9768:9768" \
    nats:2.11.6 -c /keus-iot-platform/nats-conf/main.conf`;

  await $`podman run --privileged --name kiotp_node_manager_leaf_server -d \
    --restart always \
    --log-driver k8s-file \
    --log-opt path=/data/keus-iot-platform/logs/kiotp_node_manager_leaf_server.json \
    --log-opt max-size=20mb \
    --log-opt max-file=10 \
    -p "9769:9769" -p "9770:9770" \
    -e NODE_ENV=production \
    -v /data/keus-iot-platform:/keus-iot-platform \
    --network kiotp-network \
    nats:2.11.6 \
    -c /keus-iot-platform/storage/node-leaf/leaf.conf`;

  await $`podman run --privileged --name kiotp_node_manager_server -d \
    --restart always \
    --log-driver k8s-file \
    --log-opt path=/data/keus-iot-platform/logs/kiotp_node_manager_server.json \
    --log-opt max-size=20mb \
    --log-opt max-file=10 \
    --entrypoint /bin/bash \
    -e NODE_ENV=production \
    -p "3000:3000" \
    --network kiotp-network \
    -v /data/keus-iot-platform:/keus-iot-platform \
    node:20.11.1 \
    /keus-iot-platform/starter-scripts/start-node-manager-server.sh`;

  await $`mkdir -p /data/keus-iot-platform/storage/mongodb-data`;
  await $`podman run --name mongo -d \
    --restart always \
    -p 27017:27017 \
    -v /data/keus-iot-platform/storage/mongodb-data:/data/db \
    -v /data/keus-iot-platform/starter-scripts/mongod.conf:/etc/mongod.conf \
    docker.io/library/mongo:6 --config /etc/mongod.conf`;

  let checkInProgress = false;
  setInterval(async function () {
    if (!checkInProgress) {
      checkInProgress = true;
      try {
        console.log('Checking podman containers');
        let stoppedContainersStr = (await $`podman ps -a --filter status=exited --format "{{.ID}}"`).stdout;
        let stoppedContainersList = stoppedContainersStr.split('\n');
  
        for (let i = 0; i < stoppedContainersList.length; i++) {
          await nothrow($`podman start ${stoppedContainersList[i]}`);
        }

        checkInProgress = false;
      } catch (err) {
        console.log('Failed to check podman containers status', err);
        checkInProgress = false;
      }
    }
  }, 120000);
})();