#!/bin/sh

cd /keus-iot-platform/node-manager/server/
node ./index.js
